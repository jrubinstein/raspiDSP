/* ACDf LADSPA plugin, version 1.02 
   Copyright 2015 Charlie Laub, GPLv3 

  ACDf is a LADSPA plugin for implementing filters for loudspeaker crossovers
  as described in the Active Crossover Designer tools, a set of Excel tools
  for designing crossovers based on driver measurements. See the documentation
  that accompanies this code or the Active Crossover Designer web site for 
  information on how to call this plugin correctly.  

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.

  CREDITS:

  Much of the code here was adapted from previous work by:
  Matthias Nagorni (VCF filters)
  Richard Taylor (rt-plugins) 
  Steve Harris (swh-plugins)
*/

#include <string.h>
#include <stdlib.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include <ladspa.h>
#include <string>

#define D_(s) (s)
#define DENORMALKILLER 1.e-15; //1.e-15 corresponds to -300dB
  //DENORMALKILLER is added to the filter output to avoid denormal values that 
  //may slow the calculation on some hardware when very small values are
  //produced. The added signal is a square wave at the Nyquist frequency.


//order of parameters:
#define ACDf_TYPE         0 
#define ACDf_POLARITY     1 
#define ACDf_GAIN         2 
#define ACDf_FP           3 
#define ACDf_QP           4 
#define ACDf_FZ           5 
#define ACDf_QZ           6 
#define ACDf_INPUT        7 
#define ACDf_OUTPUT       8 


static LADSPA_Descriptor *ACDfDescriptor = NULL;

typedef struct {
  double dn;
  double x1, x2, y1, y2;
  double b0, b1, b2, a1, a2;
} biquad;


typedef struct {
	LADSPA_Data *type;
	LADSPA_Data *polarity;
	LADSPA_Data *gain;
	LADSPA_Data *Fp;
	LADSPA_Data *Qp;
	LADSPA_Data *Fz;
	LADSPA_Data *Qz;
  LADSPA_Data rate;
  biquad * filter;
	LADSPA_Data *input;
	LADSPA_Data *output;
} ACDf;


const LADSPA_Descriptor *ladspa_descriptor(unsigned long index) {
	switch (index) {
	case 0:
		return ACDfDescriptor;
	default:
		return NULL;
	}
}


LADSPA_Handle instantiateACDf(const LADSPA_Descriptor *descriptor, 
                                    unsigned long sample_rate) {
 
  ACDf *pluginData = (ACDf *)malloc(sizeof(ACDf));
  pluginData->rate = (LADSPA_Data)sample_rate;

	biquad *f = NULL;
	f = (biquad *)malloc(sizeof(biquad));
	pluginData->filter = f;

  return (LADSPA_Handle)pluginData;
}


void connectPortACDf(LADSPA_Handle instance, unsigned long port, LADSPA_Data *data) {
  ACDf *pluginData = (ACDf *)instance;
	switch (port) {
	case ACDf_TYPE:
		pluginData->type = data;
		break;
	case ACDf_POLARITY:
		pluginData->polarity = data;
		break;
	case ACDf_GAIN:
		pluginData->gain = data;
		break;
	case ACDf_FP:
		pluginData->Fp = data;
		break;
	case ACDf_QP:
		pluginData->Qp = data;
		break;
	case ACDf_FZ:
		pluginData->Fz = data;
		break;
	case ACDf_QZ:
		pluginData->Qz = data;
		break;
	case ACDf_INPUT:
		pluginData->input = data;
		break;
	case ACDf_OUTPUT:
		pluginData->output = data;
		break;
	}
}




void activateACDf(LADSPA_Handle instance) {
  ACDf *pluginData = (ACDf *)instance;
	biquad *f = pluginData->filter;
  const LADSPA_Data ftype = *(pluginData->type);
  const LADSPA_Data fpolarity = *(pluginData->polarity); 
  const LADSPA_Data gain = *(pluginData->gain);
  const LADSPA_Data Fop = *(pluginData->Fp); 
  const LADSPA_Data Qop = *(pluginData->Qp);
  const LADSPA_Data Foz = *(pluginData->Fz);
  const LADSPA_Data Qoz = *(pluginData->Qz);
  const LADSPA_Data SR = pluginData->rate;

	//initialize some values...
  f->x1 = 0.0;
	f->x2 = 0.0;
	f->y1 = DENORMALKILLER;
	f->y2 = DENORMALKILLER;
  f->dn = DENORMALKILLER;

/* ====== BEGIN CODE TO CALCULATE FILTER TRANSFER FUNCTION COEFFICIENTS ========== */
  double voltage_gain, VL, VH, Wp, Qp;
  int type; //type is used internally to select filter
  type = roundf((float)ftype); //round to nearest integer 
  voltage_gain = pow(10.0,(0.05*gain)); //calculate voltage gain
  //if reverse polarity is indicated, multiple voltage gain by -1 
  if (roundf((float)fpolarity) == -1) voltage_gain *= -1.0;  
  Qp = Qop; //initialize pole Q for calculations

  if (type < 20) // first order filters begin here -----------------------------
    switch (type) {
    case 0: //gain with polarity
      f->b0 = voltage_gain;
      f->b1 = 0.0;
      f->b2 = 0.0;
      f->a1 = 0.0;
      f->a2 = 0.0;
    break;
    case 1: //1st order lowpass filter with gain and polarity
      VL = 1.0;
      VH = 0.0;
      Wp = tan(M_PI*Fop/SR);
      f->b0 = voltage_gain*(VL*Wp+VH)/(Wp+1.0);
      f->b1 = voltage_gain*(VL*Wp-VH)/(Wp+1.0);
      f->b2 = 0.0;
      f->a1 = (Wp-1.0)/(Wp+1.0);
      f->a2 = 0.0;
    break;
    case 2: //1st order highpass filter with gain and polarity 
      VL = 0.0;
      VH = 1.0;
      Wp = tan(M_PI*Fop/SR);
      f->b0 = voltage_gain*(VL*Wp+VH)/(Wp+1.0);
      f->b1 = voltage_gain*(VL*Wp-VH)/(Wp+1.0);
      f->b2 = 0.0;
      f->a1 = (Wp-1.0)/(Wp+1.0);
      f->a2 = 0.0;
    break;
    case 3: //first order all-pass filter 
      VL = 1.0;
      VH = -1.0;
      Wp = tan(M_PI*Fop/SR);
      f->b0 = (VL*Wp+VH)/(Wp+1.0);
      f->b1 = (VL*Wp-VH)/(Wp+1.0);
      f->b2 = 0.0;
      f->a1 = (Wp-1.0)/(Wp+1.0);
      f->a2 = 0.0;
    break;
    case 4: //1st order low shelf specified by Fop and gain
      VL = pow(10.0, 0.05*gain);
      VH = 1.0;
      Wp = tan(M_PI*Fop/SR);
      Wp *= fmax(1.0,1.0/VL);
      f->b0 = (VL*Wp+VH)/(Wp+1.0);
      f->b1 = (VL*Wp-VH)/(Wp+1.0);
      f->b2 = 0.0;
      f->a1 = (Wp-1.0)/(Wp+1.0);
      f->a2 = 0.0;
    break;
    case 5: //1st order high shelf specified by Fop and gain
      VL = 1.0;
      VH = pow(10.0, 0.05*gain);
      Wp = tan(M_PI*Fop/SR);
      Wp *= fmin(1.0,VH);
      f->b0 = (VL*Wp+VH)/(Wp+1.0);
      f->b1 = (VL*Wp-VH)/(Wp+1.0);
      f->b2 = 0.0;
      f->a1 = (Wp-1.0)/(Wp+1.0);
      f->a2 = 0.0;
    break;
    default:
      //if user supplies a non-supported filter type silence is returned
      f->b0 = 0.0;
      f->b1 = 0.0;
      f->b2 = 0.0;
      f->a1 = 0.0;
      f->a2 = 0.0;
  }
  else // second order filters begin here --------------------------------------
  {
    double Qz, VB, Wz, Wp2, Wz2, denom;
    switch (type) {
    case 21: //2nd order lowpass filter with gain and polarity
      VL = 1.0;
      VB = 0.0;
      VH = 0.0;
      Qz = Qp;
      Wp = tan(M_PI*Fop/SR);
      Wz = Wp;
      Wp2 = Wp*Wp;
      Wz2 = Wz*Wz;
      denom = Wp2+Wp/Qp+1.0;
      f->b0 = voltage_gain*(VL*Wz2+VB*Wz/Qz+VH)/denom;
      f->b1 = voltage_gain*2.0*(VL*Wz2-VH)/denom;
      f->b2 = voltage_gain*(VL*Wz2-VB*Wz/Qz+VH)/denom;
      f->a1 = 2.0*(Wp2-1.0)/denom;
      f->a2 = (Wp2-Wp/Qp+1.0)/denom;
    break;
    case 22: //2nd order highpass filter with gain and polarity
      VL = 0.0;
      VB = 0.0;
      VH = 1.0;
      Qz = Qp;
      Wp = tan(M_PI*Fop/SR);
      Wz = Wp;
      Wp2 = Wp*Wp;
      Wz2 = Wz*Wz;
      denom = Wp2+Wp/Qp+1.0;
      f->b0 = voltage_gain*(VL*Wz2+VB*Wz/Qz+VH)/denom;
      f->b1 = voltage_gain*2.0*(VL*Wz2-VH)/denom;
      f->b2 = voltage_gain*(VL*Wz2-VB*Wz/Qz+VH)/denom;
      f->a1 = 2.0*(Wp2-1.0)/denom;
      f->a2 = (Wp2-Wp/Qp+1.0)/denom;
    break;
    case 23: //2nd order all-pass filter
      VL = 1.0;
      VB = -1.0;
      VH = 1.0;
      Qz = Qp;
      Wp = tan(M_PI*Fop/SR);
      Wz = Wp;
      Wp2 = Wp*Wp;
      Wz2 = Wz*Wz;
      denom = Wp2+Wp/Qp+1.0;
      f->b0 = (VL*Wz2+VB*Wz/Qz+VH)/denom;
      f->b1 = 2.0*(VL*Wz2-VH)/denom;
      f->b2 = (VL*Wz2-VB*Wz/Qz+VH)/denom;
      f->a1 = 2.0*(Wp2-1.0)/denom;
      f->a2 = (Wp2-Wp/Qp+1.0)/denom;
    break;
    case 24: //2nd order notch, HP notch, and LP notch filters with gain and polarity
      VL = 1.0;
      VB = 0.0;
      VH = 1.0;
      Qz = Qoz;
      Wp = tan(M_PI*Fop/SR);
      Wz = tan(M_PI*Foz/SR);
      Wp2 = Wp*Wp;
      Wz2 = Wz*Wz;
      denom = Wp2+Wp/Qp+1.0;
      f->b0 = (VL*Wz2+VB*Wz/Qz+VH)/denom;
      f->b1 = 2.0*(VL*Wz2-VH)/denom;
      f->b2 = (VL*Wz2-VB*Wz/Qz+VH)/denom;
      f->a1 = 2.0*(Wp2-1.0)/denom;
      f->a2 = (Wp2-Wp/Qp+1.0)/denom;
      float correction_factor;
      correction_factor = Foz*Foz;
      correction_factor /= Fop*Fop;
      correction_factor *= (1.0 + f->a1 + f->a2) / (f->b0 + f->b1 + f->b2);
      f->b0 *= voltage_gain * correction_factor;
      f->b1 *= voltage_gain * correction_factor;
      f->b2 *= voltage_gain * correction_factor;
    break;
    case 25: //biquadratic filter with gain and polarity
      VL = 1.0;
      VB = 1.0;
      VH = 1.0;
      Qz = Qoz;
      Wp = tan(M_PI*Fop/SR);
      Wz = tan(M_PI*Foz/SR);
      Wp2 = Wp*Wp;
      Wz2 = Wz*Wz;
      denom = Wp2+Wp/Qp+1.0;
      f->b0 = voltage_gain*(VL*Wz2+VB*Wz/Qz+VH)/denom;
      f->b1 = voltage_gain*2.0*(VL*Wz2-VH)/denom;
      f->b2 = voltage_gain*(VL*Wz2-VB*Wz/Qz+VH)/denom;
      f->a1 = 2.0*(Wp2-1.0)/denom;
      f->a2 = (Wp2-Wp/Qp+1.0)/denom;
    break;
    case 26: //parametric EQ, digital (symmetric boost&cut) form
      VL = 1.0;
      VB = pow(10.0,0.05*gain);
      VH = 1.0;
      Qp *= fmin(1.0,VB);
      Qz = Qp;
      Wp = tan(M_PI*Fop/SR);
      Wz = Wp;
      Wp2 = Wp*Wp;
      Wz2 = Wz*Wz;
      denom = Wp2+Wp/Qp+1.0;
      f->b0 = (VL*Wz2+VB*Wz/Qz+VH)/denom;
      f->b1 = 2.0*(VL*Wz2-VH)/denom;
      f->b2 = (VL*Wz2-VB*Wz/Qz+VH)/denom;
      f->a1 = 2.0*(Wp2-1.0)/denom;
      f->a2 = (Wp2-Wp/Qp+1.0)/denom;
    break;
    case 27: //parametric EQ, analog (asymmetric boost&cut) form
      VL = 1.0;
      VB = pow(10.0,0.05*gain);
      VH = 1.0;
      Qz = Qp;
      Wp = tan(M_PI*Fop/SR);
      Wz = Wp;
      Wp2 = Wp*Wp;
      Wz2 = Wz*Wz;
      denom = Wp2+Wp/Qp+1.0;
      f->b0 = (VL*Wz2+VB*Wz/Qz+VH)/denom;
      f->b1 = 2.0*(VL*Wz2-VH)/denom;
      f->b2 = (VL*Wz2-VB*Wz/Qz+VH)/denom;
      f->a1 = 2.0*(Wp2-1.0)/denom;
      f->a2 = (Wp2-Wp/Qp+1.0)/denom;
    break;
    case 28: //2nd order low shelf, Qp=Qz=0.7071
      VL = pow(10.0,0.05*gain);
      VB = pow(VL,0.5);
      VH = 1.0;
      Qp = M_SQRT1_2;
      Qz = M_SQRT1_2;
      Wp = tan(M_PI*Fop/SR);
      Wp *= fmax(1.0,1.0/VB);
      Wz = Wp;
      Wp2 = Wp*Wp;
      Wz2 = Wz*Wz;
      denom = Wp2+Wp/Qp+1.0;
      f->b0 = (VL*Wz2+VB*Wz/Qz+VH)/denom;
      f->b1 = 2.0*(VL*Wz2-VH)/denom;
      f->b2 = (VL*Wz2-VB*Wz/Qz+VH)/denom;
      f->a1 = 2.0*(Wp2-1.0)/denom;
      f->a2 = (Wp2-Wp/Qp+1.0)/denom;
    break;
    case 29: //2nd order high shelf, Qp=Qz=0.7071
      VL = 1.0;
      VH = pow(10.0,0.05*gain);
      VB = pow(VH,0.5);
      Qp = M_SQRT1_2;
      Qz = M_SQRT1_2;
      Wp = tan(M_PI*Fop/SR);
      Wp *= fmin(1.0,VB);
      Wz = Wp;
      Wp2 = Wp*Wp;
      Wz2 = Wz*Wz;
      denom = Wp2+Wp/Qp+1.0;
      f->b0 = (VL*Wz2+VB*Wz/Qz+VH)/denom;
      f->b1 = 2.0*(VL*Wz2-VH)/denom;
      f->b2 = (VL*Wz2-VB*Wz/Qz+VH)/denom;
      f->a1 = 2.0*(Wp2-1.0)/denom;
      f->a2 = (Wp2-Wp/Qp+1.0)/denom;
    break;
    default:
      //if user supplies a non-supported filter type silence is returned
      f->b0 = 0.0;
      f->b1 = 0.0;
      f->b2 = 0.0;
      f->a1 = 0.0;
      f->a2 = 0.0;
    }
  }
  //save the transfer function parameters into the plugin filter object
	pluginData->filter = f;
/* ======= END CODE TO CALCULATE FILTER TRANSFER FUNCTION COEFFICIENTS =========== */
} //end activateACDf


void runACDf(LADSPA_Handle instance, unsigned long sample_count) {
  ACDf *pluginData = (ACDf *)instance;
  const LADSPA_Data *input = pluginData->input;
  LADSPA_Data *output = pluginData->output;
	biquad *f = pluginData->filter;
  double x,y;
	unsigned long pos;
	for (pos = 0; pos < sample_count; pos++) {
    x = (double)input[pos];
    y = f->b0 * x + f->b1 * f->x1 + f->b2 * f->x2 - f->a1 * f->y1 - f->a2 * f->y2 + f->dn;
    f->dn = -f->dn;
    f->x2 = f->x1;
    f->x1 = x;
    f->y2 = f->y1;
    f->y1 = y;
    output[pos] = (LADSPA_Data)y;
	}
} //end runACDf.


void cleanupACDf(LADSPA_Handle instance) {
	ACDf *pluginData = (ACDf *)instance;
	free(pluginData->filter);
	free(instance);
}


static class Initialiser {
public:
  Initialiser() {
    char **port_names;
    LADSPA_PortDescriptor *port_descriptors;
    LADSPA_PortRangeHint *port_range_hints;
    ACDfDescriptor = (LADSPA_Descriptor *)malloc(sizeof(LADSPA_Descriptor));

    if (ACDfDescriptor) {
      std::string text;
      //plugin descriptor info
      ACDfDescriptor->UniqueID = 5221;
      ACDfDescriptor->Label = "ACDf";
      ACDfDescriptor->Properties = LADSPA_PROPERTY_HARD_RT_CAPABLE;
      text = "Active Crossover Designer LADSPA filters version 1.02";
      ACDfDescriptor->Name = strdup(text.c_str());
      ACDfDescriptor->Maker = "Charlie Laub, 2015";
      ACDfDescriptor->Copyright = "GPLv3";
      ACDfDescriptor->PortCount = 9;

      //create storage for port_descriptors, port_range_hints, and port_names        
      port_descriptors = (LADSPA_PortDescriptor *)calloc(9,sizeof(LADSPA_PortDescriptor));
      ACDfDescriptor->PortDescriptors = (const LADSPA_PortDescriptor *)port_descriptors;
      port_range_hints = (LADSPA_PortRangeHint *)calloc(9,sizeof(LADSPA_PortRangeHint));
      ACDfDescriptor->PortRangeHints = (const LADSPA_PortRangeHint *)port_range_hints;
      port_names = (char **)calloc(9, sizeof(char*));
      ACDfDescriptor->PortNames = (const char **)port_names;
      //done creating storage. now set the descriptor, range_hints, and name for each port:

      //port = ACDf_TYPE    
      port_descriptors[ACDf_TYPE] = LADSPA_PORT_INPUT | LADSPA_PORT_CONTROL;
      text = "ACD Filter Type";
      port_names[ACDf_TYPE] = strdup(text.c_str());
      port_range_hints[ACDf_TYPE].HintDescriptor = LADSPA_HINT_BOUNDED_BELOW | LADSPA_HINT_BOUNDED_ABOVE;
      port_range_hints[ACDf_TYPE].LowerBound = 0;
      port_range_hints[ACDf_TYPE].UpperBound = 29;

      //port = ACDf_POLARITY
      port_descriptors[ACDf_POLARITY] = LADSPA_PORT_INPUT | LADSPA_PORT_CONTROL;
      text = "Filter polarity; 1=normal, -1=reverse";
      port_names[ACDf_POLARITY] = strdup(text.c_str());
      port_range_hints[ACDf_POLARITY].HintDescriptor = LADSPA_HINT_BOUNDED_BELOW | LADSPA_HINT_BOUNDED_ABOVE;
      port_range_hints[ACDf_POLARITY].LowerBound = -1;
      port_range_hints[ACDf_POLARITY].UpperBound = 1;

      //port = ACDf_GAIN    
      port_descriptors[ACDf_GAIN] = LADSPA_PORT_INPUT | LADSPA_PORT_CONTROL;
      text = "Filter Gain in dB";
      port_names[ACDf_GAIN] = strdup(text.c_str());

      //port = ACDf_FP      
      port_descriptors[ACDf_FP] = LADSPA_PORT_INPUT | LADSPA_PORT_CONTROL;
      text = "Filter Pole Frequency in Hertz";
      port_names[ACDf_FP] = strdup(text.c_str());

      //port = ACDf_QP      
      port_descriptors[ACDf_QP] = LADSPA_PORT_INPUT | LADSPA_PORT_CONTROL;
      text = "Filter Pole Q";
      port_names[ACDf_QP] = strdup(text.c_str());

      //port = ACDf_FZ      
      port_descriptors[ACDf_FZ] = LADSPA_PORT_INPUT | LADSPA_PORT_CONTROL;
      text = "Filter Zero Frequency in Hertz";
      port_names[ACDf_FZ] = strdup(text.c_str());

      //port = ACDf_QZ      
      port_descriptors[ACDf_QZ] = LADSPA_PORT_INPUT | LADSPA_PORT_CONTROL;
      text = "Filter Zero Q";
      port_names[ACDf_QZ] = strdup(text.c_str());

      //port = ACDf_INPUT   
      port_descriptors[ACDf_INPUT] = LADSPA_PORT_INPUT | LADSPA_PORT_AUDIO;
      text = "Input";
      port_names[ACDf_INPUT] = strdup(text.c_str());
      port_range_hints[ACDf_INPUT].HintDescriptor = LADSPA_HINT_BOUNDED_BELOW | LADSPA_HINT_BOUNDED_ABOVE;
      port_range_hints[ACDf_INPUT].LowerBound = -1.0;
      port_range_hints[ACDf_INPUT].UpperBound = +1.0;

      //port = ACDf_OUTPUT
      port_descriptors[ACDf_OUTPUT] = LADSPA_PORT_OUTPUT | LADSPA_PORT_AUDIO;
      text = "Output";
      port_names[ACDf_OUTPUT] = strdup(text.c_str());
      port_range_hints[ACDf_OUTPUT].HintDescriptor = LADSPA_HINT_BOUNDED_BELOW | LADSPA_HINT_BOUNDED_ABOVE;
      port_range_hints[ACDf_OUTPUT].LowerBound = -1.0;
      port_range_hints[ACDf_OUTPUT].UpperBound = +1.0;

      ACDfDescriptor->activate = activateACDf;
      ACDfDescriptor->cleanup = cleanupACDf;
      ACDfDescriptor->connect_port = connectPortACDf;
      ACDfDescriptor->deactivate = NULL;
      ACDfDescriptor->instantiate = instantiateACDf;
      ACDfDescriptor->run = runACDf;
      ACDfDescriptor->run_adding = NULL;
    }
  }
  ~Initialiser() {
    if (ACDfDescriptor) {
      free((LADSPA_PortDescriptor *)ACDfDescriptor->PortDescriptors);
      free((char **)ACDfDescriptor->PortNames);
      free((LADSPA_PortRangeHint *)ACDfDescriptor->PortRangeHints);
      free(ACDfDescriptor);
    }
  }                                      
} g_theInitialiser;
  