/* mTAP LADSPA plugin, version 1.0 
   Copyright 2015 Charlie Laub, GPLv3 */

static const int TAP_ORDER = 10; //order of the Thiran All Pass filter
static const int MAX_CHANNELS = 8; //maximum number of audio i/o channels 

/*
  mTAP is a LADSPA plugin for implementing up to MAX_CHANNELS simultaneous
  fractional delay lines. The plugin should be called with the delay in 
  milliseconds supplied as a parameterfor each channel on which audio will
  be processed. 
    
  MAX_CHANNELS: The maximum number of channels that the plugin can accept
  is controlled by the MAX_CHANNELS parameter. mTAP will properly function
  if supplied with fewer than MAX_CHANNELS of audio. To configure mTAP for
  a different maximum number of channels, change the value of MAX_CHANNELS
  to the desired number of channels and recompile. 
  
  TAP_ORDER: To implement fractional delay mTAP uses a (T)hiran (A)ll-
  (P)ass filter of order TAP_ORDER. Setting TAP_ORDER = 10 strikes a 
  balance between flat delay extension to high frequencies (this improves
  with the order) and some problems with the calculations (that become an
  issue at higher orders). In order to accomodate small fractional delays 
  with a TAP filter, up to TAP_ORDER samples of latency is introduced for 
  some channels, as needed. This is done by incorporating a simple delay 
  line into the TAP filter calculation. The user simply supplies the 
  desired delay in milliseconds for each channel to the plugin. The 
  necessary latency and TAP filter implementation is determined internally
  and implemented by the mTAP code. This presents a very simple and 
  straightforward interface to the user while providing very accurate 
  fractional flat delay, even when the desired delay is less than one
  sample period in duration.

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.

  CREDITS:

  Some concepts used in this code were adopted from previous work by:
  Richard Taylor (rt-plugins) 
  Steve Harris (swh-plugins)
*/

#include <iostream>
#include <sstream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define _USE_MATH_DEFINES
#include <math.h>
#include <ladspa.h>
#include <string>
#include <vector>
using namespace std;

static LADSPA_Descriptor *mTAP_Descriptor = NULL;

typedef struct {
  double sd; //fractional delay for this channel in samples
  int idl; //length of a simple delay line for this channel
  int io_insertion_index; //buffer index for TAP filter
  int delay_insertion_index; //buffer index for delay line
  bool useTAP; //if true the TAP will be calculated, otherwise a straight delay line will be used
  std::vector<LADSPA_Data> past_input; //buffer to hold recent inputs for the TAP filter
  std::vector<LADSPA_Data> past_output; //buffer to hold recent outputs for the TAP filter
  std::vector<LADSPA_Data> delay_line; //a simple delay line buffer
  std::vector<double> a; //stores the TAP coefficients
} mTAP_data_struct;


typedef struct {
  //this structure holds data that is communicated to the plugin from the calling program
  LADSPA_Data *delay_ptr;
  LADSPA_Data *input_ptr;
  LADSPA_Data *output_ptr;
} plugin_data_struct;


//create storage for filters that is available to all procs in this file:
static std::vector<mTAP_data_struct> TAP_filter(MAX_CHANNELS); //one per channel
static std::vector<plugin_data_struct> pluginData(MAX_CHANNELS); //one per channel
static float SR; //stores the sample rate of the data stream 
static LADSPA_Data dn = 1.e-15; //1.e-15 corresponds to -300dB
  //This value is added to the input to avoid denormal values that may slow the
  //calculation on some hardware when 0 or NULL input is supplied. The added signal
  //is a square wave at the Nyquist frequency.
const int io_buffer_size = TAP_ORDER+1; //store to prevent recalculation of this quantity
  


static inline int mod(int a, int b) {
  return ((a>=0)?(a%b):((b+a)%b));  
}


double binomial_coefficient(int N, int k) 
{
  int index;
  double result = 1.0;
  for (index=1;index<k+1;index++)
    result *= (double)(N + 1 - index) / (double)( index );
  return result;  
}


double Thiran_AP_coefficient(int k, double delta, int N)
//N is the order of the filter
//delta is the delay in sample periods. N-0.5 <= delta <= N+0.5
//k indicates which Thiran coefficient to return. 0 <= k <= N 
{
  if (k == 0) return 1.0; //unofficial Thiran coefficient a0
  int index;
  double result = 1.0; 
  for (index=0;index<N+1;index++) 
    result *= (delta - N + index) / (delta - N + k + index);
  result *= binomial_coefficient(N,k);  
  if ( (k % 2) == 1 ) result *= -1.0;
  return result;
}


const LADSPA_Descriptor *ladspa_descriptor(unsigned long index) {
  switch (index) {
  case 0:
    return mTAP_Descriptor;
  default:
    return NULL;
  }
}


LADSPA_Handle mTAP_instantiate(const LADSPA_Descriptor *descriptor, unsigned long sample_rate) {
  //dummy_ptr is used so that the function can return a pointer that is not NULL...
  char *dummy_ptr = (char *)malloc(MAX_CHANNELS * sizeof(char)); 
  SR = (float)sample_rate;
  return (LADSPA_Handle)dummy_ptr; 
}


void mTAP_connectPort(LADSPA_Handle instance, unsigned long port, LADSPA_Data *data) {
  int channel, port_type;
  channel = port / 3;
  port_type = port % 3; //types: 0=delay, 1=input, 2=output
  switch (port_type) {
  case 0:
    pluginData[channel].delay_ptr = data;
    break;
  case 1:
    pluginData[channel].input_ptr = data;
    break;
  case 2:
    pluginData[channel].output_ptr = data;
    break;
  }
}



void mTAP_activate(LADSPA_Handle instance) {
  float temp = 60.0*SR;
  int channel, additional_delay;
  unsigned int j;
  for (channel=0;channel<MAX_CHANNELS;channel++) {
    if (*(pluginData[channel].delay_ptr) == 0.0) {
      TAP_filter[channel].useTAP = false; //no delay is requested for this channel, so no TAP will be used
      TAP_filter[channel].sd = 0.0;
      TAP_filter[channel].idl = 0;
    } else {
      //convert user supplied delay time to delay in samples and find the minimum value over all channels
      TAP_filter[channel].sd = *(pluginData[channel].delay_ptr) * 0.001 * SR; //0.001 factor is because delay is in milliseconds
      if ( fabs(TAP_filter[channel].sd - round(TAP_filter[channel].sd)) > 0.01 ) {
        TAP_filter[channel].useTAP = true; //this channel requires fractional delay
        TAP_filter[channel].idl = 0;
        if (TAP_filter[channel].sd < temp) temp = TAP_filter[channel].sd; //minimum so far? If yes, then copy to temp
      } else {
        TAP_filter[channel].useTAP = false; //this channel is essentially a delay line to within 1/100th of a sample, so no TAP needed
        TAP_filter[channel].idl = (int)round(TAP_filter[channel].sd); //set delay line length
        TAP_filter[channel].sd = 0.0; //not using TAP for this channel, so set sd to zero
      }
    }
  }
  //if there were any channels using a TAP, temp now holds the minimum non-zero delay between these channels
  const int latency = max((int)0,(int)(TAP_ORDER - 0.5 - temp) + 1 );
  //latency holds an integer that will be added to each sd so that all are greater than TAP_ORDER-0.5.
  temp = latency * 1000.0 / SR;
  for (channel=0;channel<MAX_CHANNELS;channel++) {
    if (TAP_filter[channel].useTAP)
      TAP_filter[channel].sd += latency;
    else
      TAP_filter[channel].idl += latency;
  }
  //all the sd have now been adjusted so that the delays of all useTAP=true channels are greater than TAP_ORDER-0.5
  //this has been done at the expense of adding a small amount of latency to some channels
  //loop over all channels and initialize their storage
  for (channel=0;channel<MAX_CHANNELS;channel++) {
    if (TAP_filter[channel].useTAP) {
      //this channel uses a TAP
      temp = TAP_ORDER + 0.5;
      additional_delay = 0;
      //if sd  > TAP_ORDER + 0.5, calculate the delay line length that will be used to provide the additional delay
      if (TAP_filter[channel].sd > temp) {
        additional_delay = (int)(TAP_filter[channel].sd - temp) + 1;
        //subtract the additional_delay from sd and add it to the fixed delay, idl so that sd only holds the part of the total delay that will be achieved using the TAP filter
        TAP_filter[channel].sd -= additional_delay;
        TAP_filter[channel].idl += additional_delay;
      }
      //resize the vectors that hold the input and output samples the TAP filter
      //The Thiran AP coefficients run 1..order but index 0 is also used in the calculation so we will create order+1 sized storage
      TAP_filter[channel].past_input.resize(TAP_ORDER+1); //assign new size
      temp = dn;
      for ( j=0; j<TAP_filter[channel].past_input.size(); j++) {
        TAP_filter[channel].past_input[j] = temp; //intialize values to small non-zero signal
        temp *= -1.0;
      }
      TAP_filter[channel].past_output.assign(TAP_ORDER+1,0.0); //assign new size and intialize values to zero
      if (additional_delay > 0) {
        TAP_filter[channel].delay_line.resize(additional_delay); //assign new size 
        temp = dn;
        for ( j=0; j<TAP_filter[channel].delay_line.size(); j++) {
          TAP_filter[channel].delay_line[j] = temp; //intialize values to small non-zero signal
          temp *= -1.0;
        }
      }
      TAP_filter[channel].a.resize(TAP_ORDER+1); //just assign new size. Initialization follows.
      //calculate and store the TAP filter coefficients
      for ( j=0; j<TAP_filter[channel].a.size(); j++) 
        TAP_filter[channel].a[j] = Thiran_AP_coefficient(j, TAP_filter[channel].sd, TAP_ORDER);
    } //done initializations for channel using a TAP
    else 
    {
      //this channel does not use a TAP but may use a simple delay line
      TAP_filter[channel].delay_line.resize(TAP_filter[channel].idl); //assign new size
      temp = dn;
      for ( j=0; j<TAP_filter[channel].delay_line.size(); j++) {
        TAP_filter[channel].delay_line[j] = temp; //intialize values to small non-zero signal
        temp *= -1.0;
      }
    } //done initializations for channel not using a TAP
    
    TAP_filter[channel].io_insertion_index = 0;  //initialize the io_insertion_index
    TAP_filter[channel].delay_insertion_index = 0; //initialize the delay_insertion_index
  } //done initializing storage

} //end activate_mTAP


static inline LADSPA_Data Deus_ex_machina(const int channel, const LADSPA_Data input) {

  LADSPA_Data delay_line_input = input;
  if (TAP_filter[channel].useTAP) {
    //this channel uses a TAP filter
    //the Thiran AP filter transfer function is calculated as:
    //               SUM_j=0_to_N{ a_sub(N-j) * z^(-1*j) } 
    //  H (z) =  ---------------------------------------------
    //                SUM_j=0_to_N{ a_sub(j) * z^(-1*j) } 
    const int io_insertion_index = TAP_filter[channel].io_insertion_index;
    //temporarily set the past_input and past_output values at the io_insertion_index to 1.0 for use in the sum below
    TAP_filter[channel].past_input[io_insertion_index] = 1.0;
    TAP_filter[channel].past_output[io_insertion_index] = 1.0;
    double sum = 0.0; //accumulate sum in double precision
    int j; //this will be used to loop through the vector
    int k; //this will hold the index with the insertion index offset included
    
    //calculate the TAP transfer function using Direct Form I:
    for (j=0;j<=TAP_ORDER;j++) {
      k = mod(io_insertion_index - j, io_buffer_size); //shift back into range 0..size-1 using MOD
      sum += TAP_filter[channel].a[TAP_ORDER-j] * TAP_filter[channel].past_input[k]; //numerator z^-j term 
      sum -= TAP_filter[channel].a[j] * TAP_filter[channel].past_output[k]; //denominator z^-j term
    }
    sum += 1.0; //remove the first denominator term from the sum
    //sum now holds the TAP transfer function

    //update past_input and past_output with the correct values
    //to eliminate the possibility of denormal outputs forming when input is sustained at zero, add an inaudible signal, dn at f=Nyquist, to the input
    TAP_filter[channel].past_input[io_insertion_index] = input + dn;
    delay_line_input = (LADSPA_Data)(sum); //move the TAP filter result into the input for the delay line
    TAP_filter[channel].past_output[io_insertion_index] = delay_line_input; //and store it for the next TAP filter
    //increment the io_insertion_index, wrapping back to zero if necessary
    TAP_filter[channel].io_insertion_index = (io_insertion_index + 1) % io_buffer_size;
  } //done calculating the TAP filter

  //if no delay line used for this channel immediately return the delay line input:
  if (TAP_filter[channel].idl == 0 ) return delay_line_input; 
  //process the data through a delay line
  //move the delayed output from the delay line into delay_line_output
  const int delay_insertion_index = TAP_filter[channel].delay_insertion_index;
  LADSPA_Data delay_line_output = TAP_filter[channel].delay_line[delay_insertion_index]; 
  TAP_filter[channel].delay_line[delay_insertion_index] = delay_line_input; //replace it with the delay_line_input
  //increment the delay_insertion_index, wrapping back to zero if necessary
  TAP_filter[channel].delay_insertion_index = (delay_insertion_index + 1) % TAP_filter[channel].delay_line.size();
  return delay_line_output; //return delay line output
}


void mTAP_run(LADSPA_Handle instance, unsigned long sample_count) {
  LADSPA_Data *input;
  LADSPA_Data *output;
  LADSPA_Data filtered_data;
  int channel;
  unsigned long pos;

  //process the data, looping over all channels
  for (channel=0;channel<MAX_CHANNELS;channel++) {
    input = pluginData[channel].input_ptr; //set input equal to the pointer to the start of the input data for this channel
    output = pluginData[channel].output_ptr; //set output equal to the pointer to the start of the output data for this channel
    for (pos = 0; pos < sample_count; pos++) {
      filtered_data = Deus_ex_machina(channel, input[pos]);
      output[pos] = filtered_data;
      //flip the sign of the denormal killing signal
      dn = -dn;
    }
  }
} //end run_mTAP.


void mTAP_cleanup(LADSPA_Handle instance) {
  int channel;
  for (channel=0;channel<MAX_CHANNELS;channel++) {
      TAP_filter[channel].past_input = std::vector<LADSPA_Data>(); //shrink to zero
      TAP_filter[channel].past_output = std::vector<LADSPA_Data>(); //shrink to zero
      TAP_filter[channel].a = std::vector<double>(); //shrink to zero
  }
  //set pluginData pointers to NULL
  for (channel=0;channel<MAX_CHANNELS;channel++) {
    pluginData[channel].delay_ptr = NULL;
    pluginData[channel].input_ptr = NULL;
    pluginData[channel].output_ptr = NULL;
  }
  //free memory obtained via malloc for the LADSPA plugin interface
  free(instance); 
}



static class Initialiser {
public:
  Initialiser() {
    char **port_names;
    LADSPA_PortDescriptor *port_descriptors;
    LADSPA_PortRangeHint *port_range_hints;
    mTAP_Descriptor = (LADSPA_Descriptor *)malloc(sizeof(LADSPA_Descriptor));
    const unsigned long num_ports = 3 * MAX_CHANNELS;
    if (mTAP_Descriptor) {
      //plugin descriptor info
      mTAP_Descriptor->UniqueID = 5222;
      mTAP_Descriptor->Label = "mTAP";
      mTAP_Descriptor->Properties = LADSPA_PROPERTY_HARD_RT_CAPABLE;
      mTAP_Descriptor->Name = "Multi-channel fractional delay";
      mTAP_Descriptor->Maker = "Charlie Laub, 2015";
      mTAP_Descriptor->Copyright = "GPL";
      mTAP_Descriptor->PortCount = num_ports;

      //create storage for port_descriptors, port_range_hints, and port_names        
      port_descriptors = (LADSPA_PortDescriptor *)calloc(num_ports,sizeof(LADSPA_PortDescriptor));
      mTAP_Descriptor->PortDescriptors = (const LADSPA_PortDescriptor *)port_descriptors;
      port_range_hints = (LADSPA_PortRangeHint *)calloc(num_ports,sizeof(LADSPA_PortRangeHint));
      mTAP_Descriptor->PortRangeHints = (const LADSPA_PortRangeHint *)port_range_hints;
      port_names = (char **)calloc(num_ports, sizeof(char*));
      mTAP_Descriptor->PortNames = (const char **)port_names;
      //done creating storage. now set the descriptor, range_hints, and name for each port:

      unsigned int port_number;
      std::string text;
      std::ostringstream str_stream;
      for (int channel=0;channel<MAX_CHANNELS;channel++) {
        //port => CONTROL port, delay in milliseconds for this channel
        port_number = 3 * channel;
        port_descriptors[port_number] = LADSPA_PORT_INPUT | LADSPA_PORT_CONTROL;
        str_stream.str(std::string()); //empty contents, should any exist
        text = "channel ";
        str_stream << text << channel+1;
        text = " delay in milliseconds";
        str_stream << text;
        text = str_stream.str();
        port_names[port_number] = strdup(text.c_str());
        port_range_hints[port_number].HintDescriptor = LADSPA_HINT_BOUNDED_BELOW | LADSPA_HINT_BOUNDED_ABOVE;
        port_range_hints[port_number].LowerBound = 0;
        port_range_hints[port_number].UpperBound = 10;

        //port => INPUT for this channel    
        port_number = 3 * channel + 1;
        port_descriptors[port_number] = LADSPA_PORT_INPUT | LADSPA_PORT_AUDIO;
        str_stream.str(std::string()); //empty contents, should any exist
        text = "channel ";
        str_stream << text << channel+1;
        text = " audio input";
        str_stream << text;
        text = str_stream.str();
        port_names[port_number] = strdup(text.c_str());
        port_range_hints[port_number].HintDescriptor = LADSPA_HINT_BOUNDED_BELOW | LADSPA_HINT_BOUNDED_ABOVE;
        port_range_hints[port_number].LowerBound = -1.0;
        port_range_hints[port_number].UpperBound = +1.0;

        //port => OUTPUT for this channel
        port_number = 3 * channel + 2;
        port_descriptors[port_number] = LADSPA_PORT_OUTPUT | LADSPA_PORT_AUDIO;
        str_stream.str(std::string()); //empty contents, should any exist
        text = "channel ";
        str_stream << text << channel+1;
        text = " audio output";
        str_stream << text;
        text = str_stream.str();
        port_names[port_number] = strdup(text.c_str());
        port_range_hints[port_number].HintDescriptor = LADSPA_HINT_BOUNDED_BELOW | LADSPA_HINT_BOUNDED_ABOVE;
        port_range_hints[port_number].LowerBound = -1.0;
        port_range_hints[port_number].UpperBound = +1.0;
      }
      str_stream.str(std::string()); //empty contents, should any exist

      mTAP_Descriptor->activate = mTAP_activate;
      mTAP_Descriptor->cleanup = mTAP_cleanup;
      mTAP_Descriptor->connect_port = mTAP_connectPort;
      mTAP_Descriptor->deactivate = NULL;
      mTAP_Descriptor->instantiate = mTAP_instantiate;
      mTAP_Descriptor->run = mTAP_run;
      mTAP_Descriptor->run_adding = NULL;
    }
  }
  ~Initialiser() {
    if (mTAP_Descriptor) {
      free((LADSPA_PortDescriptor *)mTAP_Descriptor->PortDescriptors);
      free((char **)mTAP_Descriptor->PortNames);
      free((LADSPA_PortRangeHint *)mTAP_Descriptor->PortRangeHints);
      free(mTAP_Descriptor);
    }
  }                                      
} g_theInitialiser;

  